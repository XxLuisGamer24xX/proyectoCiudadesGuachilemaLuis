package controler;

import grafo.Grafo;
import grafo.Nodo;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.image.Image;
import java.util.ArrayList;
import java.util.List;
import grafo.Conexion;
import java.util.HashMap;
import java.util.Map;

//import java.util.Random;
public class GrafoC {
	
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private Canvas CuadroCanvas;

    @FXML
    private Button btMostrar;
    @FXML
    private Button btMostrar2;
    @FXML
    private Label mensajeError;
    // Mapa para almacenar las coordenadas de cada nodo
    private Map<Nodo, Coordenada> coordenadasNodos = new HashMap<>();

    // Método para agregar coordenadas a un nodo
    public void agregarCoordenadas(Nodo nodo, Coordenada coordenada) {
        coordenadasNodos.put(nodo, coordenada);
    }

    // Método para obtener coordenadas de un nodo
    public Coordenada obtenerCoordenadas(Nodo nodo) {
        return coordenadasNodos.get(nodo);
    }
    @FXML
    void clickMostrar(MouseEvent event) {
    	grafo.mostrarListaNodosTotal();
    	dibujarCiudades();
    }
    @FXML
    void clickMostrar2(MouseEvent event) {
    	dibujarCiudades2();
    	System.out.println("hola xd");
    }

    @FXML
    void pasarAgregar(MouseEvent event) {
    	btMostrar.setStyle("-fx-background-color: #C21010;");
    	btMostrar.setTextFill(Color.WHITE);
    }

    @FXML
    void pasarAgregar2(MouseEvent event) {
    	btMostrar2.setStyle("-fx-background-color: #C21010;");
    	btMostrar2.setTextFill(Color.WHITE);
    }

    @FXML
    void quitarAgregar(MouseEvent event) {
    	btMostrar.setStyle("-fx-background-color: black;");
    	btMostrar.setTextFill(Color.WHITE);
    }

    @FXML
    void quitarAgregar2(MouseEvent event) {
    	btMostrar2.setStyle("-fx-background-color: black;");
    	btMostrar2.setTextFill(Color.WHITE);
    }
    
    private void dibujarCiudades() {
        GraphicsContext gc = CuadroCanvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, CuadroCanvas.getWidth(), CuadroCanvas.getHeight());

        Font font = Font.font("Arial", 12);

        // Lista para almacenar las coordenadas usadas
        List<Coordenada> usedCoordinates = new ArrayList<>();

        for (Nodo ciudad : grafo.getNodos().iterable()) {
            double x, y;
            boolean validCoordinates;
            do {
                x = Math.random() * (CuadroCanvas.getWidth() - 50);
                y = Math.random() * (CuadroCanvas.getHeight() - 50);

                validCoordinates = true;
                for (Coordenada coordenada : usedCoordinates) {
                    double distance = Math.sqrt(Math.pow(x - coordenada.getX(), 2) + Math.pow(y - coordenada.getY(), 2));
                    if (distance < 50) {
                        validCoordinates = false;
                        break;
                    }
                }
            } while (!validCoordinates);

            // Agregar las coordenadas usadas a la lista
            usedCoordinates.add(new Coordenada(x, y));

            String imagenPath;
            if (ciudad.getDatos().getNumeroHabitantes() > 10) {
                imagenPath = "C:\\Users\\USUARIO\\eclipse-workspace\\sistemaCaminos\\src\\view\\img\\ciudad3.png";
            } else {
                imagenPath = "C:\\Users\\USUARIO\\eclipse-workspace\\sistemaCaminos\\src\\view\\img\\pueblo.png";
            }
            Image imagen = new Image(imagenPath);
            gc.drawImage(imagen, x, y, 50, 50);
            String nombreCiudad = ciudad.getDatos().getNombreCiudad();
            gc.setFill(Color.BLACK);
            double textWidth = new Text(nombreCiudad).getLayoutBounds().getWidth();
            double textHeight = new Text(nombreCiudad).getLayoutBounds().getHeight();
            gc.setFont(font);
            //gc.fillText(nombreCiudad, x + 25 - textWidth / 2, y + 75 + textHeight / 4);
            gc.fillText(nombreCiudad, x + 25 - textWidth / 2, y + 60 + textHeight / 4);

        }
    }

    private void dibujarCiudades2() {
        GraphicsContext gc = CuadroCanvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, CuadroCanvas.getWidth(), CuadroCanvas.getHeight());

        Font font = Font.font("Arial", 12);

        // Mapa para almacenar las coordenadas de las ciudades
        Map<Nodo, Coordenada> coordenadasCiudades = new HashMap<>();

        for (Nodo ciudad : grafo.getNodos().iterable()) {
            double x, y;
            boolean validCoordinates;
            do {
                x = Math.random() * (CuadroCanvas.getWidth() - 50);
                y = Math.random() * (CuadroCanvas.getHeight() - 50);

                validCoordinates = true;
                for (Coordenada coordenada : coordenadasCiudades.values()) {
                    double distance = Math.sqrt(Math.pow(x - coordenada.getX(), 2) + Math.pow(y - coordenada.getY(), 2));
                    if (distance < 50) {
                        validCoordinates = false;
                        break;
                    }
                }
            } while (!validCoordinates);

            // Almacenar las coordenadas en el mapa
            coordenadasCiudades.put(ciudad, new Coordenada(x, y));

            String imagenPath;
            if (ciudad.getDatos().getNumeroHabitantes() > 10) {
                imagenPath = "C:\\Users\\USUARIO\\eclipse-workspace\\sistemaCaminos\\src\\view\\img\\ciudad3.png";
            } else {
                imagenPath = "C:\\Users\\USUARIO\\eclipse-workspace\\sistemaCaminos\\src\\view\\img\\pueblo.png";
            }
            Image imagen = new Image(imagenPath);
            gc.drawImage(imagen, x, y, 50, 50);
            String nombreCiudad = ciudad.getDatos().getNombreCiudad();
            gc.setFill(Color.BLACK);
            double textWidth = new Text(nombreCiudad).getLayoutBounds().getWidth();
            double textHeight = new Text(nombreCiudad).getLayoutBounds().getHeight();
            gc.setFont(font);
            gc.fillText(nombreCiudad, x + 25 - textWidth / 2, y + 60 + textHeight / 4);
        }

        // Dibujar conexiones
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(1);
        for (Conexion conexion : grafo.getConexiones().iterable()) {
            Nodo ciudadA = conexion.getCiudadA();
            Nodo ciudadB = conexion.getCiudadB();

            Coordenada coordenadaCiudadA = coordenadasCiudades.get(ciudadA);
            Coordenada coordenadaCiudadB = coordenadasCiudades.get(ciudadB);

            double centroX1 = coordenadaCiudadA.getX() + 25; // X del centro de la imagen
            double centroY1 = coordenadaCiudadA.getY() + 25; // Y del centro de la imagen
            double centroX2 = coordenadaCiudadB.getX() + 25; // X del centro de la imagen
            double centroY2 = coordenadaCiudadB.getY() + 25; // Y del centro de la imagen

            double distanciaX = centroX2 - centroX1;
            double distanciaY = centroY2 - centroY1;

            double distanciaTotal = Math.sqrt(distanciaX * distanciaX + distanciaY * distanciaY);

            double direccionX = distanciaX / distanciaTotal;
            double direccionY = distanciaY / distanciaTotal;

            double centroLineaX = (centroX1 + centroX2) / 2;
            double centroLineaY = (centroY1 + centroY2) / 2;

            gc.strokeLine(centroX1, centroY1, centroX2, centroY2);

            // Dibujar kilómetros en el centro de la línea
            String kilometros = String.valueOf(conexion.getKilometros());
            double kilometrosTextWidth = new Text(kilometros).getLayoutBounds().getWidth();
            double kilometrosTextHeight = new Text(kilometros).getLayoutBounds().getHeight();
            gc.setFill(Color.BLACK);
            gc.fillText(kilometros, centroLineaX - kilometrosTextWidth / 2, centroLineaY + kilometrosTextHeight / 4);
        }
    }






}
