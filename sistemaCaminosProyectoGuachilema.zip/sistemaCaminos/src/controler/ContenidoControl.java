package controler;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import grafo.Grafo;
public class ContenidoControl {
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private AnchorPane ap;  
    @FXML
    private Button btAnadir;

    @FXML
    private Button btBuscar;

    @FXML
    private Button btEditar;

    @FXML
    private Button btEliminar;

    @FXML
    private Button btInicio;

    @FXML
    private Button btMostrar;
    
    @FXML
    private BorderPane dp;
    @FXML
    void anadirEncima(MouseEvent event) {
    	btAnadir.setStyle("-fx-background-color: #C21010;");
    	btAnadir.setTextFill(Color.WHITE);
    }

    @FXML
    void anadirSalir(MouseEvent event) {
    	btAnadir.setStyle("-fx-background-color: transparent;");
    	btAnadir.setTextFill(Color.WHITE);
    }

    @FXML
    void buscarEncima(MouseEvent event) {
    	btBuscar.setStyle("-fx-background-color: #C21010;");
    	btBuscar.setTextFill(Color.WHITE);
    }

    @FXML
    void buscarSalir(MouseEvent event) {
    	btBuscar.setStyle("-fx-background-color: transparent;");
    	btBuscar.setTextFill(Color.WHITE);
    }

    @FXML
    void editarEncima(MouseEvent event) {
    	btEditar.setStyle("-fx-background-color: #C21010;");
    	btEditar.setTextFill(Color.WHITE);
    }

    @FXML
    void editarSalir(MouseEvent event) {
    	btEditar.setStyle("-fx-background-color: transparent;");
    	btEditar.setTextFill(Color.WHITE);
    }

    @FXML
    void eliminarEncima(MouseEvent event) {
    	btEliminar.setStyle("-fx-background-color: #C21010;");
    	btEliminar.setTextFill(Color.WHITE);
    }

    @FXML
    void eliminarSalir(MouseEvent event) {
    	btEliminar.setStyle("-fx-background-color: transparent;");
    	btEliminar.setTextFill(Color.WHITE);
    }

    @FXML
    void inicioEncima(MouseEvent event) {
    	btInicio.setStyle("-fx-background-color: #C21010;");
    	btInicio.setTextFill(Color.WHITE);
    }

    @FXML
    void inicioSalir(MouseEvent event) {
    	btInicio.setStyle("-fx-background-color: transparent;");
    	btInicio.setTextFill(Color.WHITE);
    }

    @FXML
    void mostrarEncima(MouseEvent event) {
    	btMostrar.setStyle("-fx-background-color: #C21010;");
    	btMostrar.setTextFill(Color.WHITE);
    }

    @FXML
    void mostrarSalir(MouseEvent event) {
    	btMostrar.setStyle("-fx-background-color: transparent;");
    	btMostrar.setTextFill(Color.WHITE);
    }
    
    //------------------------------------------------------------
    //Controladores cuando hace click en los botones
    //------------------------------------------------------------
    @FXML
    void pagAnadir(MouseEvent event) {
    	cargarPaginas("pagAnadir", grafo);    	
    }

    @FXML
    void pagEditar(MouseEvent event) {
    	cargarPaginas("pagConexion", grafo);
    }

    @FXML
    void pagEliminar(MouseEvent event) {
    	cargarPaginas("pagEliminar", grafo);
    }

    @FXML
    void pagInicio(MouseEvent event) {
    	dp.setCenter(ap);
    }
    @FXML
    void pagBuscar(MouseEvent event) {
    	cargarPaginas("pagBusqueda", grafo);
    }
    @FXML
    void pagMostrar(MouseEvent event) {
    	cargarPaginas("dibujarGrafo", grafo);
    	System.out.println("------------------------------------------");
    	System.out.println("       Entramos a dibujar el nodo");
    	System.out.println("------------------------------------------");    	
    }
  
    private void cargarPaginas(String pagina, Grafo grafo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/" + pagina + ".fxml"));
            Parent root = loader.load();

            // Obtener el controlador de la página cargada
            Object controller = loader.getController();
            // Verificar el tipo de controlador y pasar la instancia de Lista
            if(pagina=="dibujarGrafo") {
                if (controller instanceof GrafoC) {
                	GrafoC grafoC = (GrafoC) controller;
                	grafoC.setGrafo(grafo);
                }
            }
            if(pagina=="pagAnadir") {
                if (controller instanceof PaginaAnadirControler) {
                    PaginaAnadirControler paginaAnadirControler = (PaginaAnadirControler) controller;
                    paginaAnadirControler.setGrafo(grafo);   
                }
            }
            if(pagina=="pagBusqueda") {
                if (controller instanceof BuscarC) {
                	BuscarC buscar = (BuscarC) controller;
                	buscar.setGrafo(grafo);
                }
            }
//            if(pagina=="pagEliminar") {
//                if (controller instanceof EliminarC) {
//                	EliminarC eliminar = (EliminarC) controller;
//                	eliminar.setGrafo(grafo);
//                }
//            }
            if(pagina=="pagConexion") {
                if (controller instanceof ConexionC) {
                	ConexionC conexion = (ConexionC) controller;
                	conexion.setGrafo(grafo);
                }
            }
            dp.setCenter(root);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}