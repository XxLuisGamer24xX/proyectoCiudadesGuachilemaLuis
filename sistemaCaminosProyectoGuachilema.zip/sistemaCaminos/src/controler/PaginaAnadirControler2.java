package controler;

import grafo.Grafo;
import grafo.Nodo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import lista.Datos;

public class PaginaAnadirControler2 {
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private Button btAgregar;

    @FXML
    private Label lbUser;

    @FXML
    private Label lbUser1;

    @FXML
    private Label lbUser2;

    @FXML
    private Label lbUser21;

    @FXML
    private Label lbUser22;

    @FXML
    private Label mensajeError;

    @FXML
    private TextField txtAlcalde;

    @FXML
    private TextField txtCiudad;

    @FXML
    private TextField txtHabitantes;

    @FXML
    private TextField txtProvincia;

    @FXML
    private TextField txtRegion;

    @FXML
    void clickAgregar(MouseEvent event) {
    	String ciudad= txtCiudad.getText();
    	String provincia= txtProvincia.getText();
    	String alcalde= txtAlcalde.getText();
    	String region= txtRegion.getText();
    	String habitantes= txtHabitantes.getText();
    	
    	if (ciudad==""|| provincia==""|| alcalde==""||region==""|| txtHabitantes.getText()=="") {
    		mensajeError.setText("Llene todos los campos");
    	}
    	else {
    		Integer habitantesInt = Integer.parseInt(habitantes);
    		if(habitantesInt<=0) {
    			mensajeError.setText("Habitantes incorrectos");    			
    		}
    		else { 
    			Datos datos = new Datos(ciudad, provincia, alcalde, region,habitantesInt);
    	        Nodo ciudadNueva = new Nodo(datos);     	        
    	        grafo.agregarNodo(ciudadNueva);		
    			mensajeError.setText("Se guardó con éxito"); 
    		}    		
    	}    
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
    	btAgregar.setStyle("-fx-background-color: #C21010;");
    	btAgregar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
    	btAgregar.setStyle("-fx-background-color: black;");
    	btAgregar.setTextFill(Color.WHITE);
    }
    void pagAnadir(MouseEvent event) {
        //nose que porner aquí xd
    }


}