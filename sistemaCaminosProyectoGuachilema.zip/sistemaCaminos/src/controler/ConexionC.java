package controler;

import grafo.Grafo;
import grafo.Nodo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class ConexionC {
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private Button btMostrar;
    @FXML
    private Label mensajeError;
    @FXML
    private TextField txtDestino;
    @FXML
    private TextField txtKilometros;
    @FXML
    private TextField txtOrigen;
    @FXML
    private TextField txtVia;
    @FXML
    void clickMostrar(MouseEvent event) {
    	String ciudadOrigen, ciudadDestino, kilometros, via;
    	ciudadOrigen=txtOrigen.getText();
    	ciudadDestino=txtDestino.getText();
    	kilometros=txtKilometros.getText();
    	via=txtVia.getText();
    	if(ciudadOrigen=="" || ciudadDestino==""|| kilometros==""|| via=="") {
    		mensajeError.setText("Llene todos los campos");
    	}
    	//Cuando si llenan todos los datos
    	else {
    		
    		double distanciaK = Double.parseDouble(kilometros);
    		if(grafo.buscarCiudad(ciudadOrigen)==null ||grafo.buscarCiudad(ciudadDestino)==null ) {
    			if(grafo.buscarCiudad(ciudadOrigen)==null) {
    				txtOrigen.setText("No existe ciudad");
    			}
    			if (grafo.buscarCiudad(ciudadDestino)==null ) {
    				txtDestino.setText("No existe ciudad");
    			}
    			mensajeError.setText("Existe algún mal entendido con algún dato");
    		}
    		if(distanciaK<=0) {
    			txtKilometros.setText("La distancia mínima es (1)");
    			mensajeError.setText("Existe algún mal entendido con algún dato");
    		}
    		
    		
    		
    		//Si todo está correcto guarda la conexión
    		if (grafo.buscarCiudad(ciudadOrigen)!=null && grafo.buscarCiudad(ciudadDestino)!=null && distanciaK>=0) {
    			Nodo ciudadO, ciudadDes;
    			ciudadO=grafo.buscarCiudad(ciudadOrigen);
    			ciudadDes=grafo.buscarCiudad(ciudadDestino);
    			grafo.conectarNodos(ciudadO, ciudadDes, distanciaK, via);
    			mensajeError.setText("Se conectó correctamente");
    			System.out.println(ciudadO.obtenerListaVecinos());
    		}
    	}
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
        btMostrar.setStyle("-fx-background-color: #C21010;");
        btMostrar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
        btMostrar.setStyle("-fx-background-color: black;");
        btMostrar.setTextFill(Color.WHITE);
    }

}
