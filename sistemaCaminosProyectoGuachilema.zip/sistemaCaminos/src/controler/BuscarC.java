package controler;

import grafo.Grafo;
import grafo.Nodo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class BuscarC {
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private Button btBuscar;

    @FXML
    private Label lbUser;

    @FXML
    private Label lbUser1;

    @FXML
    private Label lbUser2;

    @FXML
    private Label lbUser21;

    @FXML
    private Label lbUser22;

    @FXML
    private Label lbUser221;

    @FXML
    private Label mensajeError;

    @FXML
    private TextField txtAlcalde;

    @FXML
    private TextField txtCiudad;

    @FXML
    private TextField txtConexion;

    @FXML
    private TextField txtHabitantes;

    @FXML
    private TextField txtProvincia;

    @FXML
    private TextField txtRegion;

    @FXML
    void clickAgregar(MouseEvent event) {
    	String nombreCiudad=txtCiudad.getText();  	
    	if(grafo.buscarCiudad(nombreCiudad)==null) {
    		txtProvincia.setText("");   
    		txtAlcalde.setText("");   
    		txtRegion.setText("");   
    		txtHabitantes.setText("");  
    		txtConexion.setText("");  
    		mensajeError.setText(nombreCiudad+" no existe");
    	}    	
    	else {      		
    		Nodo ciudadEncontrada=grafo.buscarCiudad(nombreCiudad);
    		mensajeError.setText("Se encontró con exito");    		 		
    		String provincia=ciudadEncontrada.getDatos().getProvincia();
    		String alcalde=ciudadEncontrada.getDatos().getAlcalde();
    		String region=ciudadEncontrada.getDatos().getRegion();
    		Integer habitantes=ciudadEncontrada.getDatos().getNumeroHabitantes();
    		String conexionesCiudad=ciudadEncontrada.obtenerListaVecinos();
    		//Double conexionT=personaEncontrada.getPrecio();    		
    		//muestro en las cajas de texto  
    		txtProvincia.setText(provincia);   
    		txtAlcalde.setText(alcalde);   
    		txtRegion.setText(region);   
    		txtHabitantes.setText(""+habitantes); 
    		txtConexion.setText(conexionesCiudad);
    	}
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
    	btBuscar.setStyle("-fx-background-color: #C21010;");
    	btBuscar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
    	btBuscar.setStyle("-fx-background-color: black;");
    	btBuscar.setTextFill(Color.WHITE);
    }

}
