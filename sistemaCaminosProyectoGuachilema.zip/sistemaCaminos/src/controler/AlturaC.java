package controler;
import grafo.Grafo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class AlturaC {
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private Button btMostrar;

    @FXML
    private Label mensajeError;

    @FXML
    private TextField txtAltura;

    @FXML
    void clickMostrar(MouseEvent event) {
    	int altura=5;
    	txtAltura.setText(""+altura);
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
        btMostrar.setStyle("-fx-background-color: #C21010;");
        btMostrar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
        btMostrar.setStyle("-fx-background-color: black;");
        btMostrar.setTextFill(Color.WHITE);
    }


}
