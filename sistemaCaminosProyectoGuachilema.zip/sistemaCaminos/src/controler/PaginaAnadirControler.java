package controler;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import lista.Datos;
import grafo.Grafo;
import java.util.ArrayList;
import java.util.List;
import grafo.Nodo;
public class PaginaAnadirControler {
	Grafo grafo;
    public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
    @FXML
    private Button btAgregar;

    @FXML
    private ComboBox<String> comboProvincias;

    @FXML
    private ComboBox<String> comboRegiones;

    @FXML
    private Label lbUser;

    @FXML
    private Label lbUser1;

    @FXML
    private Label lbUser2;

    @FXML
    private Label lbUser21;

    @FXML
    private Label lbUser22;

    @FXML
    private Label mensajeError;

    @FXML
    private TextField txtAlcalde;

    @FXML
    private TextField txtCiudad;

    @FXML
    private TextField txtHabitantes;

    // Listas de provincias y regiones
    private List<String> provincias = new ArrayList<>();
    private List<String> regiones = new ArrayList<>();
    @FXML
    void clickAgregar(MouseEvent event) {
    	String ciudad = txtCiudad.getText();
        String alcalde = txtAlcalde.getText();
        String habitantesStr = txtHabitantes.getText();
        String provincia = comboProvincias.getValue(); // Obtener la provincia seleccionada del ComboBox
        String region = comboRegiones.getValue();     // Obtener la región seleccionada del ComboBox

        if (ciudad.isEmpty() || alcalde.isEmpty() || habitantesStr.isEmpty() || provincia == null || region == null) {
            mensajeError.setText("Llene todos los campos y seleccione provincia y región");
        } else {
            try {
                int habitantesInt = Integer.parseInt(habitantesStr);
                if (habitantesInt <= 0) {
                    mensajeError.setText("Habitantes incorrectos");
                } else {
                    Datos datos = new Datos(ciudad, provincia, alcalde, region, habitantesInt);
                    Nodo ciudadNueva = new Nodo(datos);
                    grafo.agregarNodo(ciudadNueva);
                    mensajeError.setText("Se guardó con éxito");
                }
            } catch (NumberFormatException e) {
                mensajeError.setText("Ingrese un valor válido para habitantes");
            }
        }
    }
    @FXML
    void initialize() {
        // Llenar las listas de provincias y regiones
    	provincias.add("Azuay");
    	provincias.add("Bolívar");
    	provincias.add("Cañar");
    	provincias.add("Carchi");
    	provincias.add("Chimborazo");
    	provincias.add("Cotopaxi");
    	provincias.add("El Oro");
    	provincias.add("Esmeraldas");
    	provincias.add("Galápagos");
    	provincias.add("Guayas");
    	provincias.add("Imbabura");
    	provincias.add("Loja");
    	provincias.add("Los Ríos");
    	provincias.add("Manabí");
    	provincias.add("Morona Santiago");
    	provincias.add("Napo");
    	provincias.add("Orellana");
    	provincias.add("Pastaza");
    	provincias.add("Pichincha");
    	provincias.add("Santa Elena");
    	provincias.add("Santo Domingo de los Tsáchilas");
    	provincias.add("Sucumbíos");
    	provincias.add("Tungurahua");
    	provincias.add("Zamora Chinchipe");
//Lista para el otro comboBox
        regiones.add("Costa");
        regiones.add("Sierra");
        regiones.add("Oriente");

        comboProvincias.getItems().addAll(provincias);
        comboRegiones.getItems().addAll(regiones);
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
        btAgregar.setStyle("-fx-background-color: #C21010;");
        btAgregar.setTextFill(Color.WHITE);
    }

    @FXML
    void quitarAgregar(MouseEvent event) {
        btAgregar.setStyle("-fx-background-color: black;");
        btAgregar.setTextFill(Color.WHITE);
    }

}
