package grafo;
import lista.Datos;
import lista.Lista;
public class Nodo {
    Datos datos;
    Lista<Nodo> vecinos;
    public Nodo(Datos datos) {
        this.datos = datos;
        this.vecinos = new Lista<>();
    }
    // Método para agregar un vecino (vértice adyacente)
    public void agregarVecino(Nodo vecino) {
        vecinos.agregar(vecino);
    }
    
    @Override
    public String toString() {
        return "Nodo{" +
                "datos=" + datos +
                '}';
    }
    public String obtenerListaVecinos() {
        if (vecinos.vacio()) {
            return "No hay conexiones por el momento";
        }
        
        StringBuilder listaVecinos = new StringBuilder();
        for (Nodo vecino : vecinos.iterable()) {
            listaVecinos.append(vecino.getDatos().getNombreCiudad()).append(", ");
        }        
        // Eliminar la última coma y espacio
        listaVecinos.setLength(listaVecinos.length() - 2);      
        return listaVecinos.toString();
    }
	public Datos getDatos() {
		return datos;
	}
	public void setDatos(Datos datos) {
		this.datos = datos;
	}
	public Lista<Nodo> getVecinos() {
		return vecinos;
	}
	public void setVecinos(Lista<Nodo> vecinos) {
		this.vecinos = vecinos;
	}
    
}