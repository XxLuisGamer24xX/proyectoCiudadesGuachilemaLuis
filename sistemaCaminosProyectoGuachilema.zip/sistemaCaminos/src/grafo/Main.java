package grafo;

import lista.Datos;

public class Main {
    public static void main(String[] args) {
    	// Crear un nuevo grafo
        Grafo grafo = new Grafo();

        // Crear nodos con datos                           
        Datos datos1 = new Datos("Santo domingo", "SantoDomingo", "Rigoberto Pacheco", "Costa", 123456789);
        Nodo ciudad1 = new Nodo(datos1);

        Datos datos2 = new Datos("Quito", "Pichincha", "Luis Guachilema", "Sierra", 123);
        Nodo ciudad2 = new Nodo(datos2);
        
        Datos datos3 = new Datos("Esmeraldas", "Esmeraldas", "Erickson", "Costa", 1332);
        Nodo ciudad3 = new Nodo(datos3);
        
        Datos datos4 = new Datos("Loja", "Loja", "Erickson", "Costa", 1332);
        Nodo ciudad4 = new Nodo(datos4);
        // Agregar nodos al grafo
        grafo.agregarNodo(ciudad1);
        grafo.agregarNodo(ciudad2);
        grafo.agregarNodo(ciudad3);
        grafo.agregarNodo(ciudad4);       
        
        if(grafo.buscarCiudad("Loja")==null) {
        	System.out.println("No existe");
        }
        else {
        	Nodo nodoEncontrado=grafo.buscarCiudad("Loja");
        	System.out.println("Si existe"+ nodoEncontrado.getDatos().getNombreCiudad());
        }
        // Conectar nodos con atributos (grafo no dirigido)
        grafo.conectarNodos(ciudad1, ciudad2, 100.0, "Autopista");
        grafo.conectarNodos(ciudad1, ciudad4, 200.0, "Roca");
        grafo.conectarNodos(ciudad4, ciudad3, 300.0, "Roca");
        grafo.conectarNodos(ciudad3, ciudad2, 300.0, "Roca");
        //grafo.conectarNodos(ciudad1, ciudad3, 50.0, "Autopista");
        
        // Mostrar las ciudades conectadas mediante adyacencia
        //System.out.println("Ciudades conectadas por adyacencia:");
        //grafo.mostrarCiudadesConectadasSoloAdyacencia();
        // Mostrar todas las conexiones entre ciudades
        System.out.println("----------------------------------------------");
        System.out.println("   Todas las conexiones entre ciudades:");
        System.out.println("----------------------------------------------");
        grafo.mostrarCiudadesConectadas();
        // Buscar todas las rutas entre dos ciudades
        System.out.println("----------------------------------------------");
        System.out.println("Todas las rutas entre Ciudad1 y Ciudad3:");
        System.out.println("----------------------------------------------");
        //grafo.buscarTodasLasRutas(ciudad1, ciudad3);
        
//        System.out.println("---------------------------------------------");   
//        // Utilizando el iterable para recorrer la lista
//        grafo.mostrarCiudadesConectadasSoloAdyacencia();
//        grafo.mostrarCiudadesConectadas();
        System.out.println("----------------------------------------------");
        System.out.println("Todas las rutas entre Ciudad1 y Ciudad3 (Backtracking):");
        System.out.println("----------------------------------------------");
        grafo.buscarTodasLasRutasBacktracking(ciudad1, ciudad3);
    }
}
