package grafo;
import java.util.Set;
import lista.Lista;
import java.util.HashSet;
import java.util.ArrayList;
public class Grafo {
	String pruebaXd="Este es un mensaje de prueba";
	Lista<Nodo> nodos;
	ListaAdyacente<Object> listasAdyacente;
	Lista<Conexion> conexiones;
	public Grafo() {
		this.nodos = new Lista<>();
		this.conexiones = new Lista<>();
	}
	//----------------------------------------------
	//    Método para agregar un nodo al grafo
	//----------------------------------------------
	public void agregarNodo(Nodo nodo) {
		//Implementamos un método de la clase lista
		nodos.agregar(nodo);
	}
	//-----------------------------------------------------------------------------------------
	//Me retorna el nodo si encuentra en la lista de vértices una ciudad con el mismo nombre a buscar
	//-----------------------------------------------------------------------------------------
	public Nodo buscarCiudad(String nombreCiudad) {
	    int contador = 0;
	    
	    
	    
	    Nodo nodoEncontrado = null;
	    for (Nodo nodo : nodos.iterable()) {            
	        if (nodo.getDatos().getNombreCiudad().equals(nombreCiudad)) {
	            contador = contador + 1;
	            nodoEncontrado = nodo;              	        
	        }
	    }
	    if (contador == 0) {
	        return null;
	    } else {
	        return nodoEncontrado;
	    }
	}

	//--------------------------------------------------------
	// Método para conectar dos nodos (vértices) en el grafo
	//--------------------------------------------------------
	public void conectarNodos(Nodo nodo1, Nodo nodo2) {
		nodo1.agregarVecino(nodo2);
		nodo2.agregarVecino(nodo1);
	}
	//--------------------------------------------------------------------------------
	// Método para conectar dos nodos (vértices) en el grafo con atributos adicionales
	//--------------------------------------------------------------------------------
	public void conectarNodos(Nodo nodo1, Nodo nodo2, double kilometros, String tipoVia) {
		//lista interna para el nodo
		nodo1.agregarVecino(nodo2); 
		nodo2.agregarVecino(nodo1);
		//-----------------------------------------------------------------------------------------
		// Crear una conexión con los atributos proporcionados y agregarla a la lista de conexiones
		//-----------------------------------------------------------------------------------------
		//lista conexiones 
		Conexion conexion = new Conexion(nodo1, nodo2, kilometros, tipoVia);
		//lista 
		conexiones.agregar(conexion);
	}

	//-----------------------------------------------------------------------------------------------------------------
	//Método que me permite mostrar la lista adyacente de las ciudades conectadas y las propiedasdes de sus conexiones
	//-----------------------------------------------------------------------------------------------------------------
	public void mostrarCiudadesConectadas() {
		for (Conexion conexion : conexiones.iterable()) {
			Nodo ciudadA = conexion.getCiudadA();
			Nodo ciudadB = conexion.getCiudadB();
			double kilometros = conexion.getKilometros();
			String tipoVia = conexion.getTipoVia();
			System.out.println("Conexión entre " + ciudadA.getDatos().getNombreCiudad() + " y " + ciudadB.getDatos().getNombreCiudad() + ": " +
					"Kilómetros: " + kilometros + ", Tipo de vía: " + tipoVia);
		}
	}
	//-----------------------------------------------------------------------------------------------------------------
	//Método que me permite mostrar la lista adyacente solo de las ciuaddes conectadas
	//-----------------------------------------------------------------------------------------------------------------
	public void mostrarCiudadesConectadasSoloAdyacencia() {
		// Obtener la lista de nodos del grafo
		Lista<Nodo> nodosDelGrafo = getNodos();
		// Crear una lista para las listas de vecinos
		Lista<Lista<Nodo>> listasVecinos = new Lista<>();        
		// Recorrer la lista de nodos utilizando un bucle for-each
		for (Nodo nodo : nodosDelGrafo.iterable()) {
			// Verificar si la lista de vecinos no está vacía antes de agregarla
			if (!nodo.getVecinos().vacio()) {
				listasVecinos.agregar(nodo.getVecinos());
			}
		}
		listasVecinos.recorrer();
	}
	public void mostrarListaNodosTotal() {
		System.out.println("Lista de nodos en el grafo:");
		for (Nodo nodo : nodos.iterable()) {
			System.out.println("Nodo: " + nodo.getDatos().getNombreCiudad()); // Cambiar esto según la estructura de tus nodos
		}
	}
	//Retorna la lista de todas las ciudades creadas 
	public Lista<Nodo> getNodos() {
		return nodos;
	}
	public void setNodos(Lista<Nodo> nodos) {
		this.nodos = nodos;
	}
	public void buscarTodasLasRutas(Nodo inicio, Nodo destino) {
		Set<ArrayList<Nodo>> rutas = new HashSet<>();
		ArrayList<Nodo> rutaActual = new ArrayList<>();
		rutaActual.add(inicio);
		buscarRutasRecursivo(destino, rutaActual, rutas);

		// Mostrar todas las rutas encontradas
		for (ArrayList<Nodo> ruta : rutas) {
			System.out.println("Ruta encontrada: " + ruta);
		}
	}

	private void buscarRutasRecursivo(Nodo destino, ArrayList<Nodo> rutaActual, Set<ArrayList<Nodo>> rutas) {
		Nodo nodoActual = rutaActual.get(rutaActual.size() - 1);

		if (nodoActual == destino) {
			// Se ha encontrado una ruta, agregarla al conjunto de rutas
			rutas.add(new ArrayList<>(rutaActual));
		} else {
			for (Nodo vecino : nodoActual.getVecinos().iterable()) {
				if (!rutaActual.contains(vecino)) {
					// Crear una copia de rutaActual y agregar el vecino a la copia
					ArrayList<Nodo> nuevaRuta = new ArrayList<>(rutaActual);
					nuevaRuta.add(vecino);
					buscarRutasRecursivo(destino, nuevaRuta, rutas);
				}
			}
		}
	}
	//----------------------------------------------------------------
	//Búsuqeda Backtraking
	//----------------------------------------------------------------
	public void buscarTodasLasRutasBacktracking(Nodo inicio, Nodo destino) {
		ArrayList<Nodo> rutaActual = new ArrayList<>();
		rutaActual.add(inicio);
		buscarRutasBacktrackingRecursivo(destino, rutaActual);
	}

	private void buscarRutasBacktrackingRecursivo(Nodo destino, ArrayList<Nodo> rutaActual) {
		Nodo nodoActual = rutaActual.get(rutaActual.size() - 1);

		if (nodoActual == destino) {
			// Se ha encontrado una ruta, mostrarla
			System.out.println("Ruta encontrada: " + rutaActual);
		} else {
			for (Nodo vecino : nodoActual.getVecinos().iterable()) {
				if (!rutaActual.contains(vecino)) {
					// Crear una copia de rutaActual y agregar el vecino a la copia
					ArrayList<Nodo> nuevaRuta = new ArrayList<>(rutaActual);
					nuevaRuta.add(vecino);
					buscarRutasBacktrackingRecursivo(destino, nuevaRuta);
				}
			}
		}
	}
	public ListaAdyacente<Object> getListasAdyacente() {
		return listasAdyacente;
	}
	public void setListasAdyacente(ListaAdyacente<Object> listasAdyacente) {
		this.listasAdyacente = listasAdyacente;
	}
	//--------------------------------------------------------------
	//Retorno la lista de conexiones establecidas
	//--------------------------------------------------------------
	public Lista<Conexion> getConexiones() {
		return conexiones;
	}
	public void setConexiones(Lista<Conexion> conexiones) {
		this.conexiones = conexiones;
	}


}