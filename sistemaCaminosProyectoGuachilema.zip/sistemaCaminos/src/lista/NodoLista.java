package lista;

public class NodoLista<T> {
    T elemento;

    NodoLista<T> siguiente;
    public NodoLista(T elemento) {
        this.elemento = elemento;
        this.siguiente = null;
    }
	public T getElemento() {
		return elemento;
	}
	public void setElemento(T elemento) {
		this.elemento = elemento;
	}
	public NodoLista<T> getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(NodoLista<T> siguiente) {
		this.siguiente = siguiente;
	}
}
